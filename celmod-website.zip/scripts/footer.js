var footer = document.createElement('div');
footer.setAttribute('id', 'footer');
footer.setAttribute('style', 'text-align: center; margin-left: auto; margin-right: auto; background-image: url(https://raw.githubusercontent.com/rockzehh/celmod-website/refs/heads/main/images/cmtextbg_bottom.png); height: 25px; width: 677px;');
document.body.appendChild(footer);